# YLReborn-FrontEnd

_A angular cms project_

* 项目环境依赖`NodeJS`, `Git`, `npm`, `bower`, `Ruby`, `compass`

* 项目用到`SCSS`及其`Compass`框架, 在`webstorm`IDE中，
选择`settings` -> `Languages & Frameworks` -> `Compass` -> 勾选`Enable Compass support`，
如果之前安装好`Compass`，在`Compass executable file`中会自动检测到，比如我的`C:/Ruby22-x64/bin/compass.bat`，点击确认即可。
不要开启`webstorm`对于`SCSS`文件的`add watcher`功能(最后通过`grunt`统一构建)。

* `bower i`安装前端依赖包，`npm i`安装`grunt`构建工具和`express`(搭建一个简单的静态服务器)，目的是快速测试构建后项目的功能。

* `npm run serve`或者`grunt serve`启动`grunt`构建工具插件提供的静态服务器功能，项目会自动在浏览器中打开，并且会监视文件变化，`livereload`等功能。
到此就可以苦逼的开发了。

* 开发结束后，发布之前，`npm run build`或者`grunt build`构建，构建最终目录是`dist`。

* `npm shrinkwrap`锁定项目依赖的`node_modules`中各`package`的版本。

* 将代码(`dist`目录和`ylreborn.js`这两个必须)提交至代码托管服务器。

* 通过`putty`等`SSH`连接工具，连接至远程服务器，将代码从代码托管服务器拉取下来，通过`pm2`发布项目。




