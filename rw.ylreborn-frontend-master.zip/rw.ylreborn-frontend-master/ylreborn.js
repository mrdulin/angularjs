/**
 * Created by Administrator on 2016/4/8.
 */
var express = require('express');
var path = require('path');

var app = express();

var static_dir = path.resolve(__dirname, 'dist');
app.use(express.static(static_dir));

app.listen(3001, function () {
    console.log('App listen on 3001 port.');
});
