/**
 * Created by Administrator on 2016/3/23.
 */
angular
    .module('YLReborn.controllers')
    .controller('LoginController', LoginController);

function LoginController($log, FormValidationService, AuthenticationService, $state, $scope, UserService) {
    var vm = this;

    angular.extend(vm, {
        login: login,
        resetPwd: resetPwd,
        username: '',
        password: '',
        formValidation: null,
        loading: false,
        err: ''
    });

    AuthenticationService.isLogin();

    function resetPwd() {
        !vm.loading && $state.go('getpwd');
    }

    $scope.$watch('vm.username + vm.password', function () {
        vm.err = '';
    });

    function login(form) {
        vm.formValidation = FormValidationService.validateLoginForm(form);
        if (vm.formValidation.formValid) {
            var User = AuthenticationService.login();

            vm.loading = true;
            User.get({username: vm.username, password: vm.password}).$promise.then(function (user) {
                if (user.UserBaseInfo) {
                    AuthenticationService.setCredentials(user);
                    user.UserBaseInfo.avatar = UserService.generateAvatar();
                } else {
                    vm.err = '登陆失败';
                }
                AuthenticationService.isLogin();
            }).catch(function (err) {
                vm.err = '服务器连接异常，请稍后重试';
            }).finally(function () {
                vm.loading = false;
            });
        }
    }

}
