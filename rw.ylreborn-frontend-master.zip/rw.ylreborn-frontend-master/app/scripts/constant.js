/**
 * Created by Administrator on 2016/3/22.
 */
angular
    .module('YLReborn')
    .constant('Const', {
        pagination: {
            pageSize: 15,
            maxSize: 5
        },
        //host: 'http://s.ylrent.com',
        nodeHost: 'http://cent.chinacloudapp.cn:3000',
        host: 'http://testapi.ylrent.com',
        baiduMapAk: '2eaLpFPPnAU6kXDHLC3zzNHRDjjhMHBn',
        city: '上海市'
    });

