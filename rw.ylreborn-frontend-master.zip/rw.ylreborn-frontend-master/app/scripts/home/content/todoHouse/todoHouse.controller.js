/**
 * Created by Administrator on 2016/3/21.
 */
angular
    .module('YLReborn.controllers')
    .controller('TodoHouseController', TodoHouseController)
    .controller('AddHouseInfoCtrl', AddHouseInfoCtrl)
    .controller('AddHouseTypeCtrl', AddHouseTypeCtrl);

function TodoHouseController($log, $uibModal, Const, Dialog, HouseService, AuthenticationService) {
    var vm = this;
    var isUserInRole = AuthenticationService.isUserInRole(['superadmin', 'admin']);

    angular.extend(vm, {
        houseDatas: null,
        pagination: angular.extend({currentPage: 1}, Const.pagination),
        add: add,
        del: del,
        requestHouseDatas: requestHouseDatas,
        pageChange: pageChange
    });

    function pageChange() {
        requestHouseDatas();
    }

    requestHouseDatas();
    function requestHouseDatas() {
        var params = {
            PageIndex: vm.pagination.currentPage,
            PageSize: vm.pagination.PageSize
        };
        HouseService.getTodoHouses(params).then(function (res) {
            var data = res.data;
            vm.houseDatas = data.HouseList;
            vm.pagination.total = data.RsCount;
        }, function (err) {
            Dialog.alert('错误', '请求待处理房源信息失败，请重试！');
        });
    }

    function _checkUserRole(userInRole, cb) {
        userInRole ? cb() : Dialog.alert('提示', '您没有权限操作，请联系管理员！');
    }

    function del(todoHouse) {
        var postBody = {
            HouseContractNo: todoHouse.ContractNo,
            Partner: "YLReborn"
        };

        _checkUserRole(isUserInRole, function () {
            Dialog.alert(null, '是否确认删除？', function () {
                return HouseService.deleteHouse(postBody).then(function (res) {
                    var data = res.data;
                    $log.info(data);
                    if (data.Result === 0) {
                        Dialog.alert('提示', '删除成功！');
                    }
                }, function (err) {
                    Dialog.alert('提示', '删除失败，请重试！');
                });
            }, true);
        });

    }

    function add(todoHouse) {
        _checkUserRole(isUserInRole, function () {
            var modalInstance = $uibModal.open({
                templateUrl: 'scripts/home/content/todoHouse/addHouseInfo/addHouseInfo.html',
                controller: 'AddHouseInfoCtrl as vm',
                size: 'md',
                resolve: {
                    Communities: ['CommunityService', 'Dialog', '$q', function (CommunityService, Dialog, $q) {
                        return CommunityService.getCommunities().then(function (rep) {
                            var data = rep.data;
                            return data.CommunityList;
                        }, function (err) {
                            Dialog.alert('错误', '请求小区数据失败，请重试!');
                            return $q.reject(err);
                        });
                    }],
                    TodoHouse: function () {
                        return todoHouse;
                    }
                }
            });

            modalInstance.result.then(function (data) {
                if (data.Result === 0) {
                    Dialog.alert('提示', '更新成功！');
                }
            });
        });
    }
}

function AddHouseInfoCtrl(TodoHouse, Dialog, $uibModalInstance, $log, MapService, $parse, $filter, Const, Communities, $uibModal, HouseService) {
    var vm = this;

    angular.extend(vm, {
        close: close,
        confirm: confirm,
        getGeo: getGeo,
        onCommunitySelect: onCommunitySelect,
        onHouseTypeSelect: onHouseTypeSelect,
        communityInputChange: communityInputChange,
        getHouseType: getHouseType,
        location: '',
        gettingLocation: false,
        monthRentMoney: '',
        dailyRentMoney: '',
        houseName: '',
        community: '',
        err: '',
        houseTypeId: '',
        communities: Communities,
        houseTypes: [],
        isSelectCommunity: false,
        addHouseType: addHouseType,
        TodoHouse: TodoHouse
    });

    function getHouseType() {
        var houseDetail = vm.TodoHouse.HouseDetail;
        return houseDetail.Shi + '房' + houseDetail.Ting + '厅' + houseDetail.Wei + '卫';
    }

    function addHouseType() {
        var modalInstance = $uibModal.open({
            templateUrl: 'scripts/home/content/todoHouse/addHouseInfo/addHouseType.html',
            controller: 'AddHouseTypeCtrl as vm',
            size: 'sm',
            resolve: {
                CommunityId: function () {
                    return vm.community.Coid
                }
            }
        });

        modalInstance.result.then(function (data) {
            if (data.Result === 0) {
                vm.houseTypes = data.HouseTypeList;
            }
        });
    }

    function communityInputChange() {
        vm.isSelectCommunity = false;
    }

    function onCommunitySelect($item, $model) {
        //$log.info($item === vm.community, $model === vm.community); //true true
        if (angular.isObject($item)) {
            vm.houseTypes = $item.HouseTypeList;
            vm.isSelectCommunity = true;
        }
    }

    function onHouseTypeSelect() {
        $log.info(vm.houseTypeId);
    }

    function getGeo() {
        var data = {address: Const.city + vm.TodoHouse.Address};
        if (!vm.TodoHouse.Address) {
            vm.err = '请填写地址';
            return false;
        }
        vm.gettingLocation = true;
        MapService.getGeo(data).then(function (resp) {
            var data = resp.data;
            var location = $parse('result.location')(data);
            $log.info('location', data);
            if (angular.isDefined(location)) {
                vm.location = $filter('number')(location.lat, 3) + ',' + $filter('number')(location.lng, 3);
            } else if (data.status !== 0) {
                vm.err = '定位失败，请检查地址是否正确';
            }
        }).finally(function () {
            vm.gettingLocation = false;
        });
    }

    function confirm() {
        var data = {
            ContractNo: vm.TodoHouse.ContractNo,
            CommunityId: vm.community.Coid,
            HousetypeId: vm.houseTypeId,
            HouseName: vm.houseName,
            CostDay: vm.dailyRentMoney,
            CostMonth: vm.monthRentMoney,
            Lat: vm.location.split(',')[0],
            Lon: vm.location.split(',')[1],
            Address: vm.TodoHouse.Address,
            Partner: 'YLReborn'
        };

        HouseService.modifyHouse(data).then(function (rep) {
            $uibModalInstance.close(rep.data);
        }, function (err) {
            Dialog.alert('错误', '补充房源信息失败，请重试！');
        });
    }

    function close() {
        $uibModalInstance.dismiss();
    }

}

function AddHouseTypeCtrl($uibModalInstance, $log, HouseService, CommunityId) {

    var vm = this;

    angular.extend(vm, {
        confirm: confirm,
        close: close,
        shi: 1,
        ting: 1,
        wei: 1
    });

    function confirm() {
        var houseTypeName = vm.shi + '房' + vm.ting + '厅' + vm.wei + '卫';

        var data = {
            "CommunityId": CommunityId,
            "HouseTypeName": houseTypeName,
            "HouseTypeDesc": "",
            "shi": vm.shi,
            "ting": vm.ting,
            "wei": vm.wei,
            "Partner": "YLReborn"
        };
        HouseService.createHouseType(data).then(function (res) {
            $uibModalInstance.close(res.data);
        }, function () {
            $uibModalInstance.dismiss();
            Dialog.alert('错误', '添加新房型失败，请重试！');
        });
    }

    function close() {
        $uibModalInstance.dismiss();
    }
}
