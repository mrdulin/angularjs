/**
 * Created by Administrator on 2016/4/14.
 */
angular
    .module('YLReborn.controllers')
    .controller('ForLeaseController', ForLeaseController);

function ForLeaseController($log, Const, communities, LeaseService, Dialog, DateService) {

    var vm = this,
        date = new Date(),
        firstDay = new Date(date.getFullYear(), date.getMonth(), 1),
        Sdate = DateService.firstDayOfMonth(date),
        Edate = DateService.lastDayOfMonth(date),
        houses = null;

    angular.extend(vm, {
        toggleDatePicker: toggleDatePicker,
        isDatepickerOpen: false,
        date: firstDay,
        format: 'yyyy-MM',
        dateOptions: {
            datepickerMode: 'month',
            minMode: 'month'
        },
        pagination: angular.extend({currentPage: 1}, Const.pagination),
        search: search,
        reset: reset,
        houses: [],
        communityList: communities,
        community: '',
        requestLeaseHouse: requestLeaseHouse,
        Scost: '',
        Ecost: '',
        pageChange: pageChange
    });

    function reset() {
        vm.Scost = vm.Ecost = vm.community = '';
        vm.pagination.currentPage = 1;
        requestLeaseHouse();
    }

    function pageChange() {
        search();
    }

    function search() {
        Sdate = DateService.firstDayOfMonth(vm.date);
        Edate = DateService.lastDayOfMonth(vm.date);
        var data = {
            Sdate: Sdate,
            Edate: Edate,
            community: vm.community.Coid,
            district: vm.community.District,
            Scost: vm.Scost,
            Ecost: vm.Ecost
        };
        data = _.omit(data, function (val, key, obj) {
            return !val;
        });
        requestLeaseHouse(data);
    }

    requestLeaseHouse();
    function requestLeaseHouse(sData) {
        var data = {
            PageIndex: vm.pagination.currentPage,
            PageSize: vm.pagination.pageSize,
            Sdate: Sdate,
            Edate: Edate
        };
        angular.extend(data, sData);

        LeaseService.query(data).then(function (res) {
            var result = res.data;
            vm.pagination.currentPage = result.CurrentPage;
            vm.pagination.total = result.RsCount;
            houses = result.HouseList;

            var ContractNos = LeaseService.getContractNos(result.HouseList);
            var postData = {rooms: ContractNos};
            return LeaseService.getStatus(postData);
        }).then(function (res) {
            if(angular.isDefined(res)) {
                var r = res.data;
                vm.houses = LeaseService.setHouseStatus(houses, r);
            } else {
                vm.houses = houses;
            }
        }).catch(function (err) {
            Dialog.alert('错误', '请求可租房源信息出错，请重试！');
        });
    }

    function toggleDatePicker() {
        vm.isDatepickerOpen = !vm.isDatepickerOpen
    }

}