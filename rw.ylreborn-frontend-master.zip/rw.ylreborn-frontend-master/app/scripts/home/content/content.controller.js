/**
 * Created by Administrator on 2016/3/21.
 */
angular
    .module('YLReborn.controllers')
    .controller('ContentController', ContentController);

function ContentController($state) {
    var vm = this;

    angular.extend(vm, {
        currentNav: $state.current.data.name
    });
}
