/**
 * Created by Administrator on 2016/3/21.
 */
angular
    .module('YLReborn.controllers')
    .controller('HouseController', HouseController)
    .controller('LogModalController', LogModalController)
    .controller('HouseDetailModalController', HouseDetailModalController);

function HouseController(HouseService, $log, $uibModal, Const, $scope, $timeout, Dialog) {
    var vm = this;
    var extendData = {};

    angular.extend(vm, {
        fangOptions: HouseService.getOptions('房', 5),
        tingOptions: HouseService.getOptions('厅', 5),
        weiOptions: HouseService.getOptions('卫', 4),
        houseList: null,
        pagination: angular.extend({currentPage: 1}, Const.pagination),
        searchContent: '',

        shi: '',
        ting: '',
        wei: '',

        requestHouseData: requestHouseData,
        checkLog: checkLog,
        pageChange: pageChange,
        reset: reset,
        checkDetail: checkDetail
    });

    function checkDetail(house) {
        var modalInstance = $uibModal.open({
            templateUrl: 'scripts/home/content/house/houseDetailModal/houseDetailModal.html',
            controller: 'HouseDetailModalController as vm',
            size: 'md',
            resolve: {
                house: ['HouseService', function (HouseService) {
                    return HouseService.getHouseDetail(house.ContractNo).then(function(res) {
                        var houseDetail = res.data.Data;
                        return HouseService.buildHouseExtendData(houseDetail);
                    });
                }]
            }
        });

        modalInstance.result.then(function (data) {
            var index = _.indexOf(vm.houseList, house);
            vm.houseList[index] = data;
        });
    }

    function reset() {
        vm.searchContent = vm.shi = vm.ting = vm.wei = '';
        extendData = {};
        requestHouseData();
        $scope.houseFilterForm.$setPristine();
        $scope.houseFilterForm.$setUntouched();
    }

    requestHouseData();
    function requestHouseData(type) {
        var data = {
            keywords: vm.searchContent,
            pageIndex: vm.pagination.currentPage,
            pageSize: vm.pagination.pageSize
        };
        if (type && angular.isString(type)) {
            if (vm[type]) {
                extendData[type] = vm[type];
            } else if (!vm[type] && angular.isDefined(extendData[type])) {
                delete extendData[type];
            }
        }
        angular.extend(data, extendData);

        HouseService.queryHouses(data).then(function _success(resp) {
            var data = resp.data;
            vm.pagination.currentPage = data.CurrentPage;
            vm.pagination.total = data.RsCount;
            vm.houseList = data.HouseList;
        }, function (err) {
            Dialog.alert('错误', '请求房源数据出错，请重试~');
        });
    }

    function pageChange() {
        requestHouseData();
    }

    function checkLog(house) {
        $uibModal.open({
            templateUrl: 'scripts/home/content/house/logModal/logModal.html',
            controller: 'LogModalController as vm',
            size: 'md',
            resolve: {
                Logs: ['HouseService', 'Dialog', '$q', function (HouseService, Dialog, $q) {
                    return HouseService.getHouseLogs({HouseContractNo: house.ContractNo}).then(function (res) {
                        return res.data.OperationLogs;
                    }, function (err) {
                        Dialog.alert('错误', '请求房源操作日志失败，请重试！');
                        return $q.reject(err);
                    });
                }]
            }
        });
    }
}

function LogModalController($uibModalInstance, $log, Logs) {

    var vm = this;

    angular.extend(vm, {
        close: close,
        logs: Logs
    });

    function close() {
        $uibModalInstance.dismiss();
    }
}

function HouseDetailModalController(AuthenticationService, $parse, $uibModalInstance, $log, house, $scope, MapService, Dialog, HouseService, $filter) {

    var vm = this,
        houseTypeMap = null,
        houseCopy = angular.copy(house);

    angular.extend(vm, {
        close: close,
        dismiss: dismiss,
        house: house,
        getLocation: getLocation,
        isModified: false,
        houseTypes: HouseService.getHouseTypes(house),
        houseTypeModify: houseTypeModify,
        gettingLocation: false,
        isUserInRole: AuthenticationService.isUserInRole
    });
    houseTypeMap = HouseService.getHouseTypeMap(vm.houseTypes);
    _setHouseType(houseTypeMap);

    function houseTypeModify() {
        vm.isModified = true;
        houseTypeMap = HouseService.getHouseTypeMap(vm.houseTypes);
        _setHouseType(houseTypeMap);
        HouseService.setHouseTypeData(vm.house, houseTypeMap);
    }

    function _setHouseType(type) {
        vm.house.HouseTypes = type.Shi + '房' + type.Ting + '厅' + type.Wei + '卫';
    }

    function dismiss() {
        vm.isModified
            ? Dialog.alert('提示', '当前修改的信息将不会保存，您确认要退出吗？', function () {
            $uibModalInstance.close(houseCopy);
        }, angular.noop)
            : $uibModalInstance.dismiss();
    }

    function getLocation() {
        var data = {address: vm.house.City + vm.house.Address};
        vm.gettingLocation = true;
        MapService.getGeo(data).then(function (resp) {
            var data = resp.data;
            var location = $parse('result.location')(data);
            if (angular.isDefined(location)) {
                vm.isModified = true;
                vm.house.HouseDetail.Lat = $filter('number')(location.lat, 3);
                vm.house.HouseDetail.Lon = $filter('number')(location.lng, 3);
            } else if (data.status !== 0) {
                Dialog.alert('错误', '定位失败，请检查地址是否正确!');
            }
        }).finally(function () {
            vm.gettingLocation = false;
        });
    }

    function close() {
        var house = vm.house,
            hDetail = house.HouseDetail,
            hExtend = house.HouseExtend;

        var data = {
            "ContractNo": house.ContractNo,                    //房源合同号
            "HouseTitle": house.HouseTitle,                     //房源名称
            "CommunityId": house.CommunityDetail.Coid,                     //小区id
            "PropertyTel": house.CommunityDetail.PropertyTel,           //物业电话021-59990021
            "HousetypeId": house.HouseTypeDetail.HoId,                      //房型id
            "Shi": houseTypeMap.Shi,                                //室
            "Ting": houseTypeMap.Ting,                             //厅
            "Wei": houseTypeMap.Wei,                                //卫
            "Chu": -1,                                //厨
            "Structurearea": hDetail.Structurearea,                  //建筑面积83.03
            "HouseName": hDetail.HouseNo,                  //房源编号14-608
            "CostDay": hDetail.Costday,                         //日租金
            "CostMonth": hDetail.Costmonth,                     //月租金
            "CostShortTermRent": hDetail.CostShortTermRent,             //短租租金
            "Lat": hDetail.Lat,                         //经度1111.99
            "Lon": hDetail.Lon,                         //纬度
            "Address": house.Address,                  //地址 徐汇区高安路14号XX
            "WaterAccount": hExtend.WaterAccount,           //自来水账户10000000001
            "ElectricityAccounts": hExtend.ElectricityAccounts,    //电费账户20000000003
            "GasAccount": hExtend.GasAccount,            //煤气（燃气账户）300000000001
            "ParkingSpaces": hExtend.ParkingSpaces,           //车位号（多个车位则用分号隔开）沪C000002
            "SalesMan": hExtend.SalesMan,                        //房源部销售员名张三
            "PhotoGalleryUrl": house.PhotoGalleryUrl,      //相册地址http://image.baidu.com/url
            "Partner": "YLReborn"                   //Partner：固定
        };

        $log.info('modify house info: ', data);

        HouseService.extendHouse(data).then(function (res) {
            var result = res.data;
            if (result.Result === 0) {
                vm.isModified = false;
                vm.dismiss();
                Dialog.alert('提示', '修改房源信息成功！');
            }
        }, function (err) {
            Dialog.alert('错误', '修改房源信息失败，请重试！');
        })
    }

    $scope.$on('houseInfoEdit', function (e, data) {
        vm.isModified = true;
    });

    $log.info(house);

}
