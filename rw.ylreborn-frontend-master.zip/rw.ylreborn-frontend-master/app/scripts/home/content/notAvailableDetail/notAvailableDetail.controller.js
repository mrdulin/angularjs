/**
 * Created by Administrator on 2016/5/5.
 */
angular
    .module('YLReborn.controllers')
    .controller('NotAvailableDetailController', NotAvailableDetailController);

function NotAvailableDetailController(oooRoomDetails) {

    var vm = this;

    angular.extend(vm, {
        oooRoomDetails:  oooRoomDetails
    });

}