/**
 * Created by Administrator on 2016/5/5.
 */
angular
    .module('YLReborn.services')
    .factory('OooReasonService', OooReasonService);

function OooReasonService(Const, $log, $http) {
    var service = {};

    angular.extend(service, {
        getOooroomDetail: getOooroomDetail,
        setVmData: setVmData
    });

    function getOooroomDetail(date) {
        var url = Const.nodeHost + '/api/room/oooroomdetails/date/' + date;
        return $http.get(url);
    }

    function setVmData(data) {
        var tmpData = _.groupBy(data, function(room) {
            return room.oooReason;
        });

        // var cleanData = tmpData['打扫'];
        // tmpData['开荒打扫'] = tmpData['开荒打扫'].concat(cleanData);
        // delete tmpData['打扫'];
        $log.info(tmpData);

        return tmpData;

    }

    return service;
}