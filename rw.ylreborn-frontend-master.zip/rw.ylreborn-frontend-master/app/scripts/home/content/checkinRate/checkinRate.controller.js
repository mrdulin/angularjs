/**
 * Created by Administrator on 2016/5/5.
 */
angular
    .module('YLReborn.controllers')
    .controller('CheckInRateController', CheckInRateController);

function CheckInRateController(StatusService, checkInRateDatas, uiGridConstants, i18nService) {
    var vm = this;
    i18nService.setCurrentLang('zh-cn');

    angular.extend(vm, {
        checkInRateDatas: checkInRateDatas,
        //occupanySum: occupanySum,
        communityName: '',
        gridOptions: {
            minRowsToShow: 12,
            showColumnFooter: true,
            enableFullRowSelection: true,
            enableGridMenu: true,
            exporterOlderExcelCompatibility: true,
            exporterMenuPdf: false,
            exporterCsvFilename: '入住率.csv',

            columnDefs: [
                {name: '小区', field: 'hotelName', enableColumnMenu: false, enableSorting: false},
                {
                    name: '入住率',
                    field: 'occupanyRate',
                    //aggregationType: uiGridConstants.aggregationTypes.avg,
                    //导出的数据是modelValue，而不是filter后的viewValue（实际数据没有变化）
                    //footerCellTemplate: '<div class="ui-grid-cell-contents">平均：<span ng-bind="col.getAggregationValue() | number: 1"></span>%</div>'
                },
                {
                    name: '入住数',
                    field: 'occupyRoomCount',
                    aggregationType: uiGridConstants.aggregationTypes.sum,
                    aggregationLabel: '总数：'
                },
                {
                    name: '不可用房',
                    field: 'oooRoomCount',
                    aggregationType: uiGridConstants.aggregationTypes.sum,
                    aggregationLabel: '总数：'
                },
                {
                    name: '总数',
                    field: 'TotalRoomCount',
                    aggregationType: uiGridConstants.aggregationTypes.sum,
                    aggregationLabel: '总数：'
                }
            ],
            data: checkInRateDatas,

            onRegisterApi: function(gridApi){
                vm.gridApi = gridApi;
                vm.gridApi.grid.registerRowsProcessor( singleFilter, 200 );
            }
        },

        datepicker: {
            open: false,
            date: new Date(),
            options: {
                maxDate: new Date(2020, 1, 1),
                startingDay: 1
            }
        },

        dateChange: dateChange,
        filterByCommunity: filterByCommunity
    });

    function filterByCommunity() {
        vm.gridApi.grid.refresh();
    }

    //There is no time for writing code comments
    function singleFilter(renderableRows) {
        var matcher = new RegExp(vm.communityName);
        renderableRows.forEach( function( row ) {
            var match = false;
            ['hotelName'].forEach(function( field ){
                if ( row.entity[field].match(matcher) ){
                    match = true;
                }
            });
            if ( !match ){
                row.visible = false;
            }
        });
        return renderableRows;
    }

    function dateChange() {
        var newDate = moment(vm.datepicker.date).format('YYYY-M-D');
        StatusService.getStatus(newDate).then(function (res) {
            var statusList = res.data;
            vm.gridOptions.data = vm.checkInRateDatas = StatusService.buildExtraData(statusList);
            //vm.occupanySum = StatusService.getOccupanySum(vm.checkInRateDatas);
        }, function (error) {
            Dialog.alert('错误', '请求数据失败，请重试！');
        });
    }

}