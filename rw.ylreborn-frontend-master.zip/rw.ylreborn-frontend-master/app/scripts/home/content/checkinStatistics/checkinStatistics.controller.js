/**
 * Created by Administrator on 2016/5/5.
 */
angular
    .module('YLReborn.controllers')
    .controller('CheckinStatisticsController', CheckinStatisticsController);

function CheckinStatisticsController(DateService, CheckInService) {

    var vm = this;
    var format = 'YYYY-M-D';

    var date = moment().format(format);

    angular.extend(vm, {
        datas: [],
        formatDate: DateService.formatDate,
        predicate: '',
        reverse: true,
        rentTypeMap: {
            all: '全部',
            daily: '日租',
            short: '中短租',
            long: '长租'
        },
        rentType: '全部',
        datepicker: {
            open: false,
            date: new Date(),
            options: {
                maxDate: new Date(2020, 1, 1),
                startingDay: 1
            }
        },
        query: query,
        order: order,
        dateChange: dateChange
    });

    function order(predicate) {
        vm.reverse = !vm.reverse;
        vm.predicate = predicate;
    }

    function dateChange() {
        query(moment(vm.datepicker.date).format(format));
    }

    query(date);
    function query(date) {
        CheckInService.getCheckins(date).then(function(res) {
            vm.datas = res.data;
        }, function(error) {
            Dialog.alert('错误', '请求数据失败，请重试！');
        });
    }


}