/**
 * Created by Administrator on 2016/5/5.
 */
angular
    .module('YLReborn.services')
    .factory('CheckInService', CheckInService);

function CheckInService(Const, $http) {
    return {
        getCheckins: function(date) {
            var url = Const.nodeHost + '/api/order/checkins/date/' + date;
            return $http.get(url);
        }
    }
}