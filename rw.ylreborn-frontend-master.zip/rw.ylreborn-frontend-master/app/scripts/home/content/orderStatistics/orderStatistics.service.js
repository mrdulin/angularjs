/**
 * Created by Administrator on 2016/5/9.
 */
angular
    .module('YLReborn.services')
    .service('OrderStatisticsServices', OrderStatisticsServices);

function OrderStatisticsServices($http, Const) {

    var service = this;

    service.getOrderStatistics = function (start, end) {
        var url = Const.nodeHost + '/api/order/checkins/start/' + start + '/end/' + end;
        return $http.get(url);
    };
}
