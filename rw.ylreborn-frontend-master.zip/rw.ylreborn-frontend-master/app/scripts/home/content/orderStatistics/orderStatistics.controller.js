/**
 * Created by Administrator on 2016/5/9.
 */
angular
    .module('YLReborn.controllers')
    .controller('OrderStatisticsController', OrderStatisticsController);

function OrderStatisticsController(OrderStatisticsServices, $log, Dialog, DateService) {
    var vm = this;

    var start = new Date(),
        end = new Date(new Date().setDate(start.getDate() + 1));

    angular.extend(vm, {
        getOrderStatistics: getOrderStatistics,
        start: start,
        end: end,
        predicate: '',
        reverse: true,
        rentTypeMap: {
            all: '全部',
            daily: '日租',
            short: '中短租',
            long: '长租'
        },
        datepickerStart: {
            open: false,
            options: {
                startingDay: 1
            }
        },
        datePickerEnd: {
            open: false,
            options: {
                startingDay: 1
            }
        },
        rentType: '全部',
        order: order,
        dateChange: dateChange
    });

    setDatepickerMaxAndMinDate();
    function setDatepickerMaxAndMinDate() {
        vm.datepickerStart.options.maxDate = vm.end;
        vm.datePickerEnd.options.minDate = vm.start;
    }

    function dateChange() {
        setDatepickerMaxAndMinDate();
        getOrderStatistics(vm.start, vm.end);
    }

    function order(predicate) {
        vm.reverse = !vm.reverse;
        vm.predicate = predicate;
    }

    getOrderStatistics(start, end);
    function getOrderStatistics(s, e) {
        sDate = DateService.formatDate(s);
        eDate = DateService.formatDate(e);

        OrderStatisticsServices.getOrderStatistics(sDate, eDate).then(function(res) {
            vm.orderStatistics = res.data;
        }, function(err) {
            Dialog.alert('提示', '请求订单统计数据失败，请重试！');
        });
    }

}