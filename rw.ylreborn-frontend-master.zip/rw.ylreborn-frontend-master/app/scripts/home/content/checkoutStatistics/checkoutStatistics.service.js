/**
 * Created by Administrator on 2016/5/5.
 */
angular
    .module('YLReborn.services')
    .factory('CheckoutService', CheckoutService);

function CheckoutService(Const, $http) {

    return {
        getCheckOuts: function(date) {
            var url = Const.nodeHost + '/api/order/checkout/date/' + date;
            return $http.get(url);
        }
    }
}