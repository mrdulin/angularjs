angular
    .module('YLReborn.controllers')
    .controller('SidebarController', SidebarController)
    .controller('UserInfoModalInstanceCtrl', UserInfoModalInstanceCtrl);

function SidebarController($uibModal, $log, User, AuthenticationService, $state, $rootScope, Dialog) {
    var vm = this;

    angular.extend(vm, {
        navs: [
            {
                parentState: 'home',
                state: 'content',
                name: '入住汇总',
                roles: ['superadmin', 'admin'],
                isDisabled: false,
                isOpen: false,
                subs: [
                    {
                        state: 'checkin_rate',
                        name: '入住率'
                    },
                    {
                        state: 'checkin_statistics',
                        name: '入住统计'
                    },
                    {
                        state: 'checkout_statistics',
                        name: '退房统计'
                    },
                    {
                        state: 'not_available_detail',
                        name: '不可用房明细'
                    },
                    {
                        state: 'order_statistics',
                        name: '订单统计'
                    }
                ]
            },
            {
                parentState: 'home',
                state: 'content',
                name: '房源信息',
                isDisabled: false,
                isOpen: false,
                subs: [
                    {
                        state: 'todo_house',
                        name: '待处理房源'
                    },
                    {
                        state: 'house',
                        name: '房源详情'
                    },
                    {
                        state: 'for_lease',
                        name: '可租房源'
                    }
                ]
            }
        ],
        openUserInfoModal: openUserInfoModal,
        user: User,
        logout: logout,
        userRole: '',
        checkUserRole: checkUserRole,
        isUserInRole: AuthenticationService.isUserInRole
    });

    function checkUserRole(nav, roles) {
        if (angular.isArray(roles)) {
            if (AuthenticationService.isUserInRole(roles)) {
                nav.isDisabled = false;
            } else {
                nav.isDisabled = true;
                Dialog.alert('提示', '您没有权限，请联系管理员');
                return false;
            }
        }
    }

    $rootScope.$on('$stateChangeSuccess', function (event, toState) {
        setNavOpen(toState.name);
    });

    setNavOpen($state.current.name);
    function setNavOpen(statename) {
        var substates;
        _.forEach(vm.navs, function (nav) {
            substates = _.pluck(nav.subs, 'state');
            if (_.contains(substates, statename.split('.')[2])) {

                nav.isOpen = true;
            }
        });
    }

    function logout() {
        AuthenticationService.clearCredentials();
        $state.go('login');
    }

    function openUserInfoModal() {
        $uibModal.open({
            templateUrl: 'scripts/home/sidebar/userInfoModal/userInfoModal.html',
            controller: 'UserInfoModalInstanceCtrl as vm',
            size: 'sm',
            resolve: {
                user: function() {return vm.user;}
            }
        });
    }
}

function UserInfoModalInstanceCtrl($log, $uibModalInstance, user, UserService, FormValidationService, Dialog) {
    var vm = this;

    angular.extend(vm, {
        close: close,
        changePwd: changePwd,
        user: user,
        showChangePwdPanel: false,
        abortChangePwd: abortChangePwd,
        confirmChangePwd: confirmChangePwd,
        oldPwd: '',
        newPwd: '',
        newPwdCfm: ''
    });

    function abortChangePwd() {
        vm.showChangePwdPanel = false;
        vm.oldPwd = vm.newPwd = vm.newPwdCfm = '';
    }

    function confirmChangePwd(form) {
        $log.info(form);
        var valid = FormValidationService.validateChangePwdForm(form);
        if(valid.formValid) {
            //TODO 调用修改密码接口
            var data = {
                "UserId": vm.user.UserId,            //用户id
                "OldPasswrod": vm.oldPwd,    //旧密码
                "NewPassword": vm.newPwd,    //新密码
                "Partner": "YLReborn"    //固定值：表示源涞国际
            };

            UserService.updatePassword(data).then(function(res) {
                var result = res.data;
                if(result.Result === 0) {
                    Dialog.alert('提示', '修改成功！');
                    abortChangePwd();
                } else {
                    Dialog.alert('提示', result.Message);
                }
            }, function(err) {
                Dialog.alert('错误', '修改失败！');
            });
        }
    }

    function close() {
        $uibModalInstance.dismiss();
    }

    function changePwd() {
        vm.showChangePwdPanel = true;
    }
}
