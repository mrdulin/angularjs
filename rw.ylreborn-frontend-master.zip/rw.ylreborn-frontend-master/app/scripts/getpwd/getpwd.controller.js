/**
 * Created by Administrator on 2016/3/23.
 */
angular
    .module('YLReborn.services')
    .controller('GetPwdController', GetPwdController);

function GetPwdController($state, $log, AuthenticationService, $interval, FormValidationService, UserService, $scope) {
    var vm = this;
    var timer;
    var getSmsCodeToken = '';

    AuthenticationService.isLogin();

    angular.extend(vm, {
        getCode: getCode,
        next: next,
        confirm: confirm,
        gettingCode: false,
        countdown: 60,
        step: 1,
        nextStepping: false,
        confirming: false,
        mobile: '',
        code: '',
        formValidation: null,
        newPwd: '',
        newPwdCfm: '',
        err: '',
        msg: '',
        redirectSecond: 3
    });

    function getCode(form) {
        var smsCodeResource = UserService.smsCode();
        vm.formValidation = FormValidationService.validateGetPwdFirstStepMobile(form);
        if(vm.formValidation.formValid) {
            _startCountdown();
            smsCodeResource.get({mobile: vm.mobile}).$promise.then(function(data) {
                if(data.Result === 0) {
                    vm.msg = '获取验证码成功，10分钟内有效';
                    vm.err = '';
                    getSmsCodeToken = data.Tokens;
                } else {
                    vm.err = data.Message;
                    vm.msg = '';
                }
            }).catch(function() {
                vm.err = '发送请求失败，请稍后重试';
                vm.msg = '';
            })
        }
    }

    function _startCountdown() {
        vm.gettingCode = true;
        timer = $interval(function() {
            if(vm.countdown > 0) {
                vm.countdown--;
            } else {
                _stopCountDown(timer);
                vm.gettingCode = false;
            }
        }, 1000);
    }

    function _stopCountDown(t) {
        if(angular.isDefined(t)) {
            $interval.cancel(t);
            t = null;
        }
    }

    function next(form) {
        vm.formValidation = FormValidationService.validateGetPwdFirstStepForm(form);
        if(vm.formValidation.formValid) {
            vm.nextStepping = true;
            var verifySmsCodeResource = UserService.verifySmsCode(getSmsCodeToken);
            verifySmsCodeResource.verify({}, {
                Mobile: vm.mobile,
                SmsCode: vm.code,
                Partner: 'YLReborn'
            }).$promise.then(function(data) {
                    if(data.VerifyResult) {
                        vm.step ++;
                        vm.err = '';
                        vm.msg = '';
                    } else {
                        vm.err = data.Message;
                        vm.msg = ''
                    }
                }).catch(function() {
                    vm.err = '发送请求失败，请稍后重试';
                    vm.msg = '';
                }).finally(function() {
                    vm.nextStepping = false;
                });
        }
    }

    function confirm(form) {
        var postBody = {
            Mobile: vm.mobile,
            SmsCode: vm.code,
            ResetPassword: vm.newPwd,
            Partner: 'YLReborn'
        };
        vm.formValidation = FormValidationService.validateSetNewPwdForm(form);
        if(vm.formValidation.formValid) {
            vm.confirming = true;
            var passwordResource = UserService.resetPassword(getSmsCodeToken);
            passwordResource.save({}, postBody).$promise.then(function(data) {
                if(data.Result === 0) {
                    timer = $interval(function() {
                        vm.msg = '重置密码成功，' + vm.redirectSecond +  '秒后自动跳转';
                        if(vm.redirectSecond > 0) {
                            vm.redirectSecond --;
                        } else if(vm.redirectSecond === 0) {
                            $interval.cancel(timer);
                            timer = null;
                            $state.go('login');
                        }
                    }, 1000);
                } else {
                    vm.err = data.Message;
                    vm.msg = '';
                }
            }).catch(function() {
                vm.err = '发送请求失败，请稍后重试';
                vm.msg = '';
            });
        }
    }

    $scope.$on('$destroy', function() {
        _stopCountDown(timer);
    });
}