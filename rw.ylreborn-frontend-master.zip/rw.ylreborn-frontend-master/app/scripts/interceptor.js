/**
 * Created by Administrator on 2016/3/24.
 */
angular
    .module('YLReborn')
    .factory('HttpInterceptor', HttpInterceptor);

function HttpInterceptor($q, $rootScope, $log, $injector) {
    return {
        request: function(config) {
            // do something on success
            var url = config.url,
                headers = config.headers;

            if(/http:/.test(config.url)) {
                loadingStart();
                if(url.indexOf('baidu') !== -1) {
                    headers.Tokens && delete headers.Tokens;
                }
            }

            return config;
        },

        requestError: function(rejection) {
            // do something on error
            loadingDone();
            return $q.reject(rejection);
        },

        response: function(response) {
            // do something on success
            if(angular.isObject(response.data)) {
                loadingDone();
            }

            return response;
        },

        responseError: function(rejection) {
            // do something on error
            loadingDone();

            if(rejection.status === 401) {
                $rootScope.$broadcast('unauthorized', rejection);
            }
            return $q.reject(rejection);
        }
    };

    function loadingStart() {
        $rootScope.loading = true;
    }

    function loadingDone() {
        var $timeout = $injector.get('$timeout');
        $timeout(function() {
            $rootScope.loading = false;
        }, 10)
    }
}