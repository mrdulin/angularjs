/**
 * Created by Administrator on 2016/4/18.
 */
angular
    .module('YLReborn.filters')
    .filter('trim', function () {
        return function (str) {
            if (!angular.isString(str)) {
                return str;
            }
            return $.trim(str);
        }
    })
    .filter('add_percent_symbol', function() {
        return function(raw) {
            return raw + '%'
        }
    });

