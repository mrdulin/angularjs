/**
 * Created by Administrator on 2016/4/13.
 */
angular
    .module('YLReborn.directives')
    .directive('focusInput', focusInput);

function focusInput($timeout, $log) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            attr.$observe('isFocus', function (newAttr) {
                if (scope.$eval(newAttr)) {
                    $timeout(function () {
                        element[0].focus();
                        element[0].select();
                    }, 10);
                }
            });
        }
    }
}