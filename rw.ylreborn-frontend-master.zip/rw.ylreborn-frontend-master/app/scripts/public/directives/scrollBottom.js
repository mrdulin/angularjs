/**
 * Created by Administrator on 2016/3/25.
 */
angular
    .module('YLReborn.directives')
    .directive('scrollBottom', function($log) {
        return {
            restrict: 'A',
            scope: {},
            link: function(scope, element, attr) {
                scope.$parent.$on('scrollContentBottom', function(e, data) {
                    if(data && data.scroll) {
                        $(element).scrollTop(element[0].scrollHeight);
                    }
                })
            }
        }
    });