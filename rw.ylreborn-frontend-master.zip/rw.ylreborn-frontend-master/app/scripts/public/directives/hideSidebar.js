/**
 * Created by Administrator on 2016/3/25.
 */
angular
    .module('YLReborn.directives')
    .directive('hideSidebar', function($log) {
        return {
            restrict: 'A',
            scope: {},
            link: function(scope, element, attr) {
                $(element).on('click', function(e) {
                    var $el = $(this);
                    if(!$el.hasClass('fix')) {
                        $el.parent().addClass('sidebar-hide').next().addClass('full')
                            .end().end().addClass('fix').find('.glyphicon').removeClass('glyphicon-triangle-left')
                            .addClass('glyphicon-triangle-right');
                    } else {
                        $el.parent().removeClass('sidebar-hide').next().removeClass('full')
                            .end().end().removeClass('fix').find('.glyphicon').removeClass('glyphicon-triangle-right')
                            .addClass('glyphicon-triangle-left');
                    }
                });
            }
        };
    });