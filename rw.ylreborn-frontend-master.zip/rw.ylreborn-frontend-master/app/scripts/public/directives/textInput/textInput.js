/**
 * Created by Administrator on 2016/4/13.
 */
angular
    .module('YLReborn.directives')
    .directive('textInput', textInput);

function textInput($log, $timeout, $rootScope) {
    return {
        restrict: 'EA',
        replace: true,
        templateUrl: 'scripts/public/directives/textInput/textInput.html',
        scope: {
            selectText: '@',
            ngModel: '=',
            modelName: '@',
            width: '@',
            defaultText: '@'
        },
        link: function (scope, element, attr) {

            if (angular.isUndefined(scope.ngModel)) {
                $log.error('textInput directive must specify a ngModel attribute');
                return;
            }
            if (angular.isUndefined(scope.modelName)) {
                $log.error('textInput directive must specify a modelName attribute');
                return;
            }

            var domInput = $(element).find('input');
            var timer;

            scope.width = scope.width || '100';
            scope.editing = false;
            scope.cacheModel = null;
            scope.model = scope.ngModel[scope.modelName];
            scope.selectText = scope.selectText || 'true';
            scope.defaultText = scope.defaultText || '点击编辑';

            scope.$watch('editing', function (newVal) {
                if (newVal) {
                    _destroyTimer();
                    timer = $timeout(function () {
                        domInput.focus();
                        scope.$eval(scope.selectText) && domInput.select();
                    }, 10);
                }
            });

            scope.focusHandler = function () {
                scope.cacheModel = scope.model;
            };

            function _destroyTimer() {
                if (timer) {
                    $timeout.cancel(timer);
                    timer = undefined;
                }
            }

            scope.keyPressEditing = function (e) {
                if (e.keyCode === 13 || e.which === 13) {
                    domInput.blur();
                }
            };

            scope.doEditing = function (modelName, model) {
                scope.editing = false;
                if (!model.length) {
                    scope.model = scope.ngModel[modelName] = scope.cacheModel;
                    scope.cacheModel = null;
                } else {
                    if (angular.equals(scope.cacheModel, scope.model)) return;
                    scope.ngModel[modelName] = scope.model;
                    $log.info(scope.ngModel[modelName]);
                    $rootScope.$broadcast('houseInfoEdit', {
                        modelName: scope.modelName,
                        modelValue: scope.model
                    });
                }
            };
        }
    }
}