/**
 * Created by Administrator on 2016/5/5.
 */
angular
    .module('YLReborn.services')
    .factory('StatusService', StatusService);

function StatusService(Const, $http, $filter) {

    return {
        getStatus: function (date) {
            var url = Const.nodeHost + '/api/status/summary/date/' + date;
            return $http.get(url);
        },

        buildExtraData: function (statusList) {
            var occupanyRate;
            angular.forEach(statusList, function (status) {
                occupanyRate = status.occupyRoomCount / (status.TotalRoomCount - status.oooRoomCount);
                status.occupanyRate = parseFloat((Number(occupanyRate) * 100).toFixed(1)) + '%';

            });
            return statusList;
        },

        getOccupanySum: function (statusList) {
            var i = 0,
                len = statusList.length,
                status,
                total = 0,
                occupany = 0,
                oooRoomCount = 0;

            for (; i < len; i++) {
                status = statusList[i];
                occupany += status.occupyRoomCount;
                total += status.TotalRoomCount;
                oooRoomCount += status.oooRoomCount;
            }

            var data = {
                total: total,
                occupany: occupany,
                oooRoomCount: oooRoomCount
            };

            data.occupanyRate = $filter('number')(data.occupany / (data.total - data.oooRoomCount), 2);

            return data;
        }
    };
}