/**
 * Created by Administrator on 2016/3/23.
 */
angular
    .module('YLReborn.services')
    .factory('FormValidationService', FormValidationService);

function FormValidationService($log) {

    var service = {};

    angular.extend(service, {
        validateLoginForm: validateLoginForm,
        validateGetPwdFirstStepForm: validateGetPwdFirstStepForm,
        validateSetNewPwdForm: validateSetNewPwdForm,
        validateGetPwdFirstStepMobile: validateGetPwdFirstStepMobile,
        validateChangePwdForm: validateChangePwdForm
    });

    function validateChangePwdForm(form) {
        var data = {formValid: true};
        return data;
    }

    function validateGetPwdFirstStepMobile(form) {
        var data = {formValid: true};
        if(form.mobile.$error.required) {
            data.errMsg = '请填写手机号';
            data.errInput = 'mobile';
            data.formValid = false;
            return data;
        } else if(form.mobile.$error.pattern) {
            data.errMsg = '手机号格式不正确';
            data.errInput = 'mobile';
            data.formValid = false;
            return data;
        } else {
            return data;
        }
    }

    function validateLoginForm(form) {
        var data = {formValid: form.$valid};
        if(form.username.$error.required) {
            data.errMsg = '请填写用户名/手机号';
            data.errInput = 'username';
            return data;
        } else if(form.password.$error.required) {
            data.errMsg = '请填写密码';
            data.errInput = 'password';
            return data;
        } else {
            return data;
        }
    }

    function validateGetPwdFirstStepForm(form) {
        var data = {formValid: form.$valid};
        if(form.mobile.$error.required) {
            data.errMsg = '请填写手机号';
            data.errInput = 'mobile';
            return data;
        } else if(form.mobile.$error.pattern) {
            data.errMsg = '手机号格式不正确';
            data.errInput = 'mobile';
            return data;
        } else if(form.code.$error.required) {
            data.errMsg = '请填写验证码';
            data.errInput = 'code';
            return data;
        } else {
            return data;
        }
    }

    function validateSetNewPwdForm(form) {
        var data = {formValid: form.$valid};
        if(form.newPwd.$error.required) {
            data.errMsg = '请填写新密码';
            data.errInput = 'newPwd';
            return data;
        } else if(form.newPwd.$error.minlength) {
            data.errMsg = '密码至少6个字符';
            data.errInput = 'newPwd';
            return data;
        } else if(form.newPwdCfm.$error.required) {
            data.errMsg = '请再次输入新密码确认';
            data.errInput = 'newPwdCfm';
            return data;
        } else if(form.newPwdCfm.$error.minlength) {
            data.errMsg = '密码至少6个字符';
            data.errInput = 'newPwdCfm';
            return data;
        } else if(form.newPwd.$modelValue !== form.newPwdCfm.$modelValue) {
            data.errMsg = '输入密码不一致';
            data.formValid = false;
            return data;
        } else {
            return data;
        }
    }

    return service;
}
