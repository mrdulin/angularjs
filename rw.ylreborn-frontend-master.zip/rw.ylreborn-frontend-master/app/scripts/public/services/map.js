/**
 * Created by Administrator on 2016/3/24.
 */
angular
    .module('YLReborn.services')
    .factory('MapService', MapService);

function MapService($http, $log, Const, $httpParamSerializerJQLike) {
    var service = {};

    angular.extend(service, {
        getGeo: getGeo
    });

    function getGeo(data) {
        var baseParams = {
            output: 'json',
            ak: Const.baiduMapAk
        };
        var params = angular.extend(baseParams, data);
        var url = 'http://api.map.baidu.com/geocoder/v2/?' + $httpParamSerializerJQLike(params) + '&callback=JSON_CALLBACK';

        return $http.jsonp(url);
    }

    return service;
}