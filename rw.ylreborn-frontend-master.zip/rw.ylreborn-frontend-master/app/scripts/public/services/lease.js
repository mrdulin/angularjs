/**
 * Created by Administrator on 2016/4/15.
 */
angular
    .module('YLReborn.services')
    .factory('LeaseService', LeaseService);

function LeaseService(Const, $http, $q, Dialog) {

    var service = {};

    angular.extend(service, {
        query: query,
        getStatus: getStatus,
        getContractNos: getContractNos,
        setHouseStatus: setHouseStatus
    });

    function setHouseStatus(houses, statusList) {
        var status;
        return _.map(houses, function (house) {
            status = _.findWhere(statusList, {contractno: house.ContractNo});
            return _.extend(house, status);
        });
    }

    function getContractNos(houses) {
        return _.pluck(houses, 'ContractNo');
    }

    function getStatus(data) {
        var url = 'http://cent.chinacloudapp.cn:3000/api/status';
        var deferred = $q.defer();
        $http.post(url, data).then(function(res) {
            deferred.resolve(res);
        }, function(err) {
            deferred.resolve(Dialog.alert('错误', '请求房态信息出错，请重试!'))
        });

        return deferred.promise;
    }

    function query(data) {
        var url = Const.host + '/Leasing/s';
        return $http.get(url, {params: data});
    }

    return service;
}