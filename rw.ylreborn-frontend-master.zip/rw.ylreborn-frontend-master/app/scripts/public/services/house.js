/**
 * Created by Administrator on 2016/3/25.
 */
angular
    .module('YLReborn.services')
    .factory('HouseService', HouseService);

function HouseService(Const, $log, $http) {

    return {
        queryHouses: function (data) {
            var url = Const.host + '/house/Search';
            return $http.get(url, {params: data});
        },

        getHouseDetail: function(contractNo) {
            var url = Const.host + '/house/detail/' + contractNo;
            return $http.get(url);
        },

        modifyHouse: function (data) {
            var url = Const.host + '/House/Modify';
            return $http.post(url, data);
        },

        extendHouse: function (data) {
            var url = Const.host + '/House/ExtendUpdate';

            return $http.post(url, data);
        },

        createHouseType: function (data) {
            var url = Const.host + '/HouseType/Create';
            return $http.post(url, data);
        },

        getTodoHouses: function (data) {
            var url = Const.host + '/House/GetWaitingForOperating';
            return $http.get(url, {params: data});
        },

        getHouseLogs: function (data) {
            var url = Const.host + '/House/OperationLog';
            return $http.get(url, {params: data});
        },

        deleteHouse: function (data) {
            var url = Const.host + '/House/Delete';
            return $http.post(url, data);
        },

        buildHouseExtendData: function (house) {
            var data = {
                ElectricityAccounts: "",
                GasAccount: "",
                HoMemo: "",
                HoeId: "",
                HouseContractNo: "",
                ParkingSpaces: "",
                SalesMan: "",
                WaterAccount: ""
            };

            !house.HouseExtend && (house.HouseExtend = data);
            return house;
        },

        getOptions: function (type, max) {
            var i = 1,
                data = {};
            for (; i <= max; i++) {
                data[i] = i + type;
            }
            return data;
        },

        getHouseTypes: function (house) {
            var typeMap = {
                Shi: '房',
                Ting: '厅',
                Wei: '卫'
            };
            var houseType = _.pick(house.HouseDetail, 'Shi', 'Ting', 'Wei');
            var data, datas = [];
            angular.forEach(houseType, function (val, key) {
                data = {
                    name: typeMap[key],
                    key: key,
                    val: val
                };
                datas.push(data);
            });
            return datas;
        },

        getHouseTypeMap: function (houseTypes) {
            var data = {};
            angular.forEach(houseTypes, function (houseType) {
                data[houseType.key] = houseType.val;
            });
            return data;
        },

        setHouseTypeData: function (house, houseType) {
            angular.forEach(houseType, function (val, key) {
                house.HouseDetail[key] = val;
            });
        }
    }

}
