/**
 * Created by Administrator on 2016/3/23.
 */
angular
    .module('YLReborn.services')
    .factory('UserService', UserService);

function UserService($log, Const, $resource, $http) {

    var service = {};
    angular.extend(service, {
        resetPassword: resetPassword,
        smsCode: smsCode,
        verifySmsCode: verifySmsCode,
        generateAvatar: generateAvatar,
        updatePassword: updatePassword
    });

    function verifySmsCode(token) {
        var url = Const.host + '/sms/verifycode';
        return $resource(url, null, {
            verify: {
                method: 'POST',
                headers: {
                    'Tokens': token
                }
            }
        });
    }

    function resetPassword(token) {
        var url = Const.host + '/user/forgot/resetpass';
        return $resource(url, null, {
            save: {
                method: 'POST',
                headers: {
                    'Tokens': token
                }
            }
        });
    }

    function updatePassword(data) {
        var url = Const.host + '/user/resetpass';
        return $http.post(url, data);
    }

    function smsCode() {
        var url = Const.host + '/GetSmsCode/:mobile';
        return $resource(url, {mobile: '@mobile'}, {
            get: {
                method: 'GET'
            }
        });
    }

    function generateAvatar() {
        return 'data:image/png;base64,' + new Identicon().toString();
    }

    return service;
}
