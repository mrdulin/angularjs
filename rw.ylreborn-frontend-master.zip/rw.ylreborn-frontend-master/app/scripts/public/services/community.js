/**
 * Created by Administrator on 2016/3/28.
 */
angular
    .module('YLReborn.services')
    .factory('CommunityService', CommunityService);

function CommunityService(Const, $http) {

    function getCommunities() {
        var url = Const.host + '/House/communitys';
        return $http.get(url);
    }

    return {
        getCommunities: getCommunities
    }
}