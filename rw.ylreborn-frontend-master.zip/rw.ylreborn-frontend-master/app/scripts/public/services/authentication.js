/**
 * Created by Administrator on 2016/3/23.
 */
angular
    .module('YLReborn')
    .factory('AuthenticationService', AuthenticationService);

function AuthenticationService($log, $resource, $cookies, $http, $rootScope, $state, Const, UserService) {
    var service = {};

    var roleMap = {
        superadmin: {code: 0, cn_name: '超级管理员', en_name: 'superadmin'},
        admin: {code: 1, cn_name: '管理员', en_name: 'admin'},
        normal: {code: 2, cn_name: '普通用户', en_name: 'normal'}
        //others...
    };

    angular.extend(service, {
        login: login,
        setCredentials: setCredentials,
        clearCredentials: clearCredentials,
        isLogin: isLogin,
        useTokenFromCookie: useTokenFromCookie,
        getUserRoleByCode: getUserRoleByCode,
        isUserInRole: isUserInRole
    });

    function getUserRoleByCode(code) {
        return _.findWhere(roleMap, {code: code});
    }

    function isUserInRole(roles) {
        var userRoleCode = $rootScope.user.UserBaseInfo.UserRole;
        var userRole = getUserRoleByCode(userRoleCode);
        return _.contains(roles, userRole.en_name);
    }

    function isLogin() {
        if($rootScope.user) {
            $state.go('home');
        }
    }

    function useTokenFromCookie() {
        var user = $cookies.getObject('user');
        if(user) {
            user.UserBaseInfo.avatar = UserService.generateAvatar();
            user.UserBaseInfo.Role = getUserRoleByCode(user.UserBaseInfo.UserRole);
            $http.defaults.headers.common.Tokens = user.Tokens;
            $rootScope.user = user;
            return user;
        }
    }

    function login() {
        var url = Const.host + '/Login/:username/:password';

        return $resource(url, {username: '@username', password: '@password'});
    }

    function setCredentials(user) {
        $rootScope.user = user;
        $cookies.putObject('user', user);
        user.UserBaseInfo.Role = getUserRoleByCode(user.UserBaseInfo.UserRole);
        $http.defaults.headers.common.Tokens = user.Tokens;
    }

    function clearCredentials() {
        $cookies.remove('user');
        $rootScope.user = null;
        delete $http.defaults.headers.common.Tokens;
    }

    return service;
}
