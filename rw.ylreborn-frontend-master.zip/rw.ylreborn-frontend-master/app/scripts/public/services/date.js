/**
 * Created by Administrator on 2016/4/15.
 */
angular
    .module('YLReborn.services')
    .factory('DateService', DateService);

function DateService($log, $filter) {

    var format = 'yyyy-M-d';

    return {
        firstDayOfMonth: function (d) {
            d.setDate(1);
            return $filter('date')(d.toISOString(), format);
        },

        lastDayOfMonth: function (d) {
            d.setMonth(d.getMonth() + 1);
            d.setDate(0);
            return $filter('date')(d.toISOString(), format);
        },

        formatDate: function (date) {
            return moment(date).utc().format('YYYY-M-D');
        }
    };
}