/**
 * Created by Administrator on 2016/3/28.
 */
angular
    .module('YLReborn.services')
    .factory('Dialog', Dialog);

function Dialog($uibModal, $log, $q) {
    var dialog = {};
    var modalBaseConfig = {
        templateUrl: 'scripts/public/services/dialog/dialog.html',
        controllerAs: 'vm',
        windowClass: 'modal-alert'
    };

    angular.extend(dialog, {
        alert: alert
    });

    function alert(title, msg, confirm, cancel) {
        var tt = title || '提示';
        $uibModal.open(angular.extend(modalBaseConfig, {
            controller: ['$uibModalInstance', '$log', function ($uibModalInstance, $log) {
                var vm = this;
                vm.tt = tt;
                vm.msg = msg;
                vm.ok = ok;
                vm.close = $uibModalInstance.dismiss;
                vm.hasCancel = !!cancel;

                function ok(){
                    if(confirm) {
                        $q.when(confirm()).then(function(data) {
                            $log.info('cb', data);
                            $uibModalInstance.close();
                        });
                    } else {
                        $uibModalInstance.close();
                    }
                }
            }]
        }));
    }
    return dialog;
}
