const webpack = require('webpack');
const path = require('path');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const join = (...args) => path.join(process.cwd(), ...args);
const env = process.env.NODE_ENV === 'production' ? 'production' : 'development';

const config = {
  entry: {
    app: join('app/index'),
    vendor: [
      'angular',
      'angular-route'
    ]
  },

  output: {
    path: join('dist'),
    filename: '[name].[chunkhash:8].js',
    publicPath: '/',
    pathinfo: true
  },

  resolve: {
    alias: {
      modules: join('app/modules')
    }
  },

  module: {
    loaders: [
      {
        test: /\.js$/,
        include: [join('app')],
        loader: 'babel'
      },
      {
        test: /\.html$/,
        exclude: [join('app/index.html')],
        loader: `ngTemplate?relativeTo=${join('app/modules')}/!html`
      }
    ]
  },

  plugins: [
    new webpack.optimize.CommonsChunkPlugin('vendor', 'vendor.[hash:8].js'),
    new HtmlWebpackPlugin({
      template: join('app/index.html'),
      filename: 'index.html'
    }),
    new CleanWebpackPlugin(join('dist'))
  ],

  devtool: 'source-map'
};

if (env) {
  config.devServer = {
    contentBase: '/',
    historyApiFallback: true,
    colors: true,
    port: 3000,
    progress: true,
    host: '0.0.0.0'
  }
}

module.exports = config;
