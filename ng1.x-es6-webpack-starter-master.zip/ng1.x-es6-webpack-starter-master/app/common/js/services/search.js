//factory

class SearchService {
  static factory($http) {
    return new SearchService($http);
  }
  constructor($http, $log) {
    this.$http = $http;
    this.$log = $log;
    this.url = 'http://it-ebooks-api.info/v1';
  }
  searchBooks(query, number) {
    const url = `${this.url}/search/${query}/page/${number}`;
    return this.$http.get(url).then(result => {
      const { Books: books, Total: total } = result.data;
      return { books, total };
    });
  }
}

SearchService.factory.$inject = ['$http', '$log'];

export default SearchService.factory;

