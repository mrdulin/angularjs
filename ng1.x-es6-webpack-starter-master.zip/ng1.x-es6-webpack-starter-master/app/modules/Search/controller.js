
class SearchController {
  constructor($log, SearchService) {
    this.$log = $log;
    this.SearchService = SearchService;
    this.query = '';
    this.page = 1;
    this.books = [];
    this.total = 0;
  }

  searchBooks() {
    this.$log.info('searchbooks', this.query);
    const query = this.query.trim();
    if (!query) return;
    this.SearchService.searchBooks(query, this.page).then(data => {
      this.books = data.books;
      this.total = data.total;
    });
  }
}

SearchController.$inject = ['$log', 'SearchService'];

export default SearchController;
