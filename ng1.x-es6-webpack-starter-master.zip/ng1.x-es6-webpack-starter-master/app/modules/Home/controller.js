class HomeController {
  constructor($log) {
    this.$log = $log;
  }
}

HomeController.$inject = ['$log'];

export default HomeController;
