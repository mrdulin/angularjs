import angular from 'angular';

import HomeController from './modules/Home/controller';
import homeViewUrl from './modules/Home/view.html';

import SearchController from './modules/Search/controller';
import searchViewUrl from './modules/Search/view.html';

import SearchServiceFactory from './common/js/services/search';

angular
  .module('app', [
    'ngRoute',
    'app.controllers',
    'app.services'
  ]);

angular.module('app.controllers', [])
  .controller('HomeController', HomeController)
  .controller('SearchController', SearchController);

angular.module('app.services', [])
  .factory('SearchService', SearchServiceFactory);

angular
  .module('app')
  .config(config);

//用箭头函数会报错
function config($routeProvider, $locationProvider) {

  $locationProvider.html5Mode(true);

  $routeProvider
    .when('/', {
      templateUrl: homeViewUrl,
      controller: 'HomeController',
      controllerAs: 'vm'
    })
    .when('/search', {
      templateUrl: searchViewUrl,
      controller: 'SearchController',
      controllerAs: 'vm'
    })
    .otherwise({ redirectTo: '/' });
};

config.$inject = ['$routeProvider', '$locationProvider'];


