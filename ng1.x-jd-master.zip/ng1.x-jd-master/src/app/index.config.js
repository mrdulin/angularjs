(function() {
  'use strict';

  angular
    .module('ng1XJd')
    .config(config);

  /** @ngInject */
  function config($logProvider) {
    // Enable log
    $logProvider.debugEnabled(true);

  }

})();
