(function () {
  'use strict';

  angular
    .module('ng1XJd')
    .service('util', util);

  /** @ngInject */
  function util() {

    angular.extend(this, {
      debounce: function debounce(fn, delay) {

        var last;
        return function () {
          var args = arguments, ctx = this;
          clearTimeout(last);
          last = setTimeout(function () {
            fn.apply(ctx, args);
          }, delay || 1000);
        }
      }
    });
  }

})();
