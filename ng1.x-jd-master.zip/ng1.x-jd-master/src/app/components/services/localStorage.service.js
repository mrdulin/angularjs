(function () {
  'use strict';

  angular
    .module('ng1XJd')
    .factory('localStorage', localStorage);

  /** @ngInject */
  function localStorage($log, $window) {

    var service = {
      set: function (key, value) {
        $window.localStorage[key] = value;
      },
      get: function (key, defaultValue) {
        return $window.localStorage[key] || defaultValue;
      },
      setObject: function (key, value) {
        $window.localStorage[key] = JSON.stringify(value);
      },
      getObject: function (key) {
        return JSON.parse($window.localStorage[key] || '{}');
      }
    };

    return service;
  }
})();
