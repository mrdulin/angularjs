(function () {

  angular.module('ng1XJd')
    .service('CommodityService', CommodityService);

  function CommodityService($log, $http, $timeout) {

    angular.extend(this, {
      getCommodities: function () {
        var datas = [
          {id: 1, name: '诺基亚6（Nokia6）4GB+64GB黑色 全网通 双卡双待 移动联通4G手机', price: '16900'},
          {id: 2, name: '诺基亚6（Nokia6）4GB+64GB黑色 全网通 双卡双待 移动联通4G手机', price: '16900'},
          {id: 3, name: '诺基亚6（Nokia6）4GB+64GB黑色 全网通 双卡双待 移动联通4G手机', price: '16900'},
          {id: 4, name: '诺基亚6（Nokia6）4GB+64GB黑色 全网通 双卡双待 移动联通4G手机', price: '16900'},
          {id: 5, name: '诺基亚6（Nokia6）4GB+64GB黑色 全网通 双卡双待 移动联通4G手机', price: '16900'},
          {id: 6, name: '诺基亚6（Nokia6）4GB+64GB黑色 全网通 双卡双待 移动联通4G手机', price: '16900'}
        ];

        return new Promise(function (resolve, reject) {
          $timeout(function () {
            resolve(datas);
          }, 2000);
        });
      }
    });

  }
})();
