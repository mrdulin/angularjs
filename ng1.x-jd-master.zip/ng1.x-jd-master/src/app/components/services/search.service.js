(function () {
  'use strict';

  angular
    .module('ng1XJd')
    .service('searchService', searchService);

  /** @ngInject */
  function searchService($log, $http) {

    angular.extend(this, {
      getKeywords: function (keywork) {
        var url = '';
        var words = [
          'angular',
          'react',
          'rxjs',
          'react-native',
          'angular',
          'react',
          'rxjs',
          'react-native',
          'angular',
          'react',
          'rxjs',
          'react-native',
          'angular',
          'react',
          'rxjs',
          'react-native'
        ]
        return new Promise(function (resolve, reject) {
          setTimeout(function () {
            resolve(words);
          }, 1000);
        })
        // return $http.get(url);
      }
    });
  }

})();
