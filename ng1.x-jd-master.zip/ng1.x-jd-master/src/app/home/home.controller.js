(function () {
  'use strict';

  angular
    .module('ng1XJd')
    .controller('HomeController', HomeController);

  /** @ngInject */
  function HomeController($log, $rootScope, localStorage, $timeout, util, searchService, $scope) {
    var vm = this;
    var HISTORY_STORAGE_KEY = 'HISTORY_KEYWORDS';
    var historyKeywords = localStorage.getObject(HISTORY_STORAGE_KEY);

    $rootScope.title = '搜索';
    $rootScope.showFooter = false;

    vm.keyword = '';
    vm.historyKeywords = angular.equals({}, historyKeywords) ? [] : historyKeywords;
    vm.autocompleteKeywords = [];
    vm.showAutocomplete = false;

    $scope.$watch(function() {
      return vm.keyword;
    }, function(newVal, oldVal) {
      if((oldVal.length > newVal.length && !newVal.length) || !oldVal.length) {
        vm.showAutocomplete = false;
      }
    });

    vm.onClearHistoryKeywords = function () {
      vm.historyKeywords.length = 0;
      localStorage.setObject(HISTORY_STORAGE_KEY, []);
    };

    vm.onSearchFormSubmit = function ($event) {
      $log.info($event);
      var keyword = vm.keyword.trim();
      if (!keyword) return;
      vm.keyword = '';
      vm.historyKeywords.push(keyword);
      localStorage.setObject(HISTORY_STORAGE_KEY, vm.historyKeywords);

      //TODO: 跳转到搜索结果页
    };

    vm.onSearchInputClear = function() {
      vm.keyword = '';
    };

    vm.onHistoryKeywordClick = function (keyword) {
      $log.info(keyword);
      //TODO: 跳转到搜索结果页
    };

    vm.onSearchInputChange = util.debounce(function () {
      if(!vm.keyword.trim()) return;
      console.log(vm.keyword);
      //TODO: 调接口autocomplete
      searchService.getKeywords(vm.keyword).then(function(words) {
        vm.autocompleteKeywords = words;
        vm.showAutocomplete = vm.autocompleteKeywords.length > 0;
        $scope.$digest();
      });
    }, 500);

    vm.onAutocompleteWordClick = function(keyword) {
      if(!keyword.trim()) return;
      $log.info(keyword);
      vm.keyword = '';
      vm.historyKeywords.push(keyword);
      localStorage.setObject(HISTORY_STORAGE_KEY, vm.historyKeywords);
      vm.showAutocomplete = false;
      //TODO: 跳转到搜索结果页
    };

  }
})();
