(function() {
  'use strict';

  angular
    .module('ng1XJd')
    .constant('moment', moment);

})();
