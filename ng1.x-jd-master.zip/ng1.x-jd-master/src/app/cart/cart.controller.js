(function() {

  angular.module('ng1XJd')
    .controller('CartController', CartController);

  function CartController($log, $scope, $rootScope, commodities) {
    var vm = this;

    angular.extend($rootScope, {
      title: '购物车',
      showFooter: true,
      scrollable: true,
      mainBottom: '8rem'
    });

    angular.extend(vm, {
      commodities: commodities,
      commodityToBeDeleted: null,

      onCommoditySwipeLeft: function(commodity) {
        vm.commodityToBeDeleted = commodity;
        // $log.info('swipe left', vm.commodityToBeDeleted);
      },

      onCommoditySwipeRight: function(commodity) {
        if(commodity.id !== vm.commodityToBeDeleted.id) return;
        vm.commodityToBeDeleted = null;
      },

      onCommodityDelete: function(commodity) {
        vm.commodities = vm.commodities.filter(function(item) {
          return item.id !== commodity.id;
        })
      }
    });



  }
})();
