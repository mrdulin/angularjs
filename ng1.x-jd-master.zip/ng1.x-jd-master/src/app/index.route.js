(function () {
  'use strict';

  angular
    .module('ng1XJd')
    .config(routeConfig);

  function routeConfig($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'app/home/home.html',
        controller: 'HomeController',
        controllerAs: 'home'
      })
      .when('/cart', {
        templateUrl: 'app/cart/cart.html',
        controller: 'CartController',
        controllerAs: 'cart',
        resolve: {
          commodities: function (CommodityService) {
            return CommodityService.getCommodities().then(function (commodities) {
              return commodities;
            });
          }
        }
      })
      .otherwise({
        redirectTo: '/'
      });
  }

})();
