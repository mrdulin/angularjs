(function() {
  'use strict';

  angular
    .module('ng1XJd', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngMessages', 'ngRoute', 'toastr']);

})();
