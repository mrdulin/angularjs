(function () {
  'use strict';

  angular
    .module('ng1XJd')
    .run(runBlock);

  /** @ngInject */
  function runBlock($log, $rootScope) {

    $log.debug('runBlock end');

    angular.extend($rootScope, {
      title: '',
      showFooter: false,
      mainBottom: '4rem',
      scrollable: false,
      footerTabs: [
        { key: 'home', name: '首页', icon: 'assets/images/icon-home.png' },
        { key: 'cart', name: '购物车', icon: 'assets/images/icon-cart.png' },
        { key: 'user', name: '我的', icon: 'assets/images/icon-user.png' }
      ],
    });

    $rootScope.$watch('[showFooter, scrollable]', function() {
      $rootScope.mainStyle = {
        bottom: $rootScope.showFooter ? $rootScope.mainBottom : 0,
        overflowY: $rootScope.scrollable ? 'auto' : 'visible'
      };
    })

  }

})();
